// Enable tooltips everywhere
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Initialize attendance circle
    const attendanceCircle = document.querySelector('.attendance-circle');
    if (attendanceCircle) {
        const percentage = attendanceCircle.getAttribute('data-percentage');
        attendanceCircle.style.setProperty('--percentage', `${percentage}%`);
    }
});

// Add confirmation for delete actions
function confirmDelete(event) {
    if (!confirm('Are you sure you want to delete this item?')) {
        event.preventDefault();
    }
}
