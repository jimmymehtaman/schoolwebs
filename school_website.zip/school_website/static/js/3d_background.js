// Optimized 3D background with better performance
let scene, camera, renderer, particles;
let mouseX = 0, mouseY = 0;
let isReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let animationFrameId;
let isVisible = true;

function init3DBackground() {
    // Only initialize if the element exists
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;

    // Setup scene
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    
    // Optimize renderer
    renderer = new THREE.WebGLRenderer({
        canvas: canvas,
        antialias: false, // Disable antialiasing for better performance
        alpha: true,
        powerPreference: "high-performance"
    });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Limit pixel ratio for better performance

    // Create particles with optimized geometry
    const particleCount = isReducedMotion ? 500 : 1000;
    const geometry = new THREE.BufferGeometry();
    const vertices = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
        vertices[i] = Math.random() * 2000 - 1000;
        vertices[i + 1] = Math.random() * 2000 - 1000;
        vertices[i + 2] = Math.random() * 2000 - 1000;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));

    // Optimize material
    const material = new THREE.PointsMaterial({
        color: 0x00ffd5,
        size: 2,
        transparent: true,
        opacity: 0.8,
        blending: THREE.AdditiveBlending,
        sizeAttenuation: false // Disable size attenuation for better performance
    });

    particles = new THREE.Points(geometry, material);
    scene.add(particles);

    camera.position.z = 1000;

    // Optimized event listeners
    const throttledMouseMove = throttle(onMouseMove, 16); // Limit to ~60fps
    const debouncedResize = debounce(onWindowResize, 250);
    
    document.addEventListener('mousemove', throttledMouseMove, { passive: true });
    window.addEventListener('resize', debouncedResize, { passive: true });
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Start animation
    animate();
}

function handleVisibilityChange() {
    isVisible = document.visibilityState === 'visible';
    if (isVisible) {
        if (!animationFrameId) {
            animate();
        }
    } else {
        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
    }
}

function onMouseMove(event) {
    mouseX = (event.clientX - window.innerWidth / 2) / 100;
    mouseY = (event.clientY - window.innerHeight / 2) / 100;
}

function onWindowResize() {
    if (!camera || !renderer) return;
    
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    if (!isVisible) return;

    animationFrameId = requestAnimationFrame(animate);

    // Optimize animations
    if (particles) {
        particles.rotation.x += 0.0001;
        particles.rotation.y += 0.0001;

        // Smooth camera movement
        camera.position.x += (mouseX - camera.position.x) * 0.03;
        camera.position.y += (-mouseY - camera.position.y) * 0.03;
        camera.lookAt(scene.position);
    }

    renderer.render(scene, camera);
}

// Utility functions for performance optimization
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init3DBackground);
} else {
    init3DBackground();
}
