from app import app, db, create_demo_data

with app.app_context():
    # Create all tables
    db.create_all()
    
    # Create demo data
    create_demo_data()
